7-class YOLO object detection dataset. electric bulb and old battery data are not included.
LED boxes cover plastic bodies only (no leads). RGB boxes cover PCB and LED lens.
All included labels were visually reviewed on contact sheets.
Similar-image groups stay together in train/val. Same capture session/background: validation is not an independent real-world accuracy estimate.
Original images are untouched. Exclusions and original paths are recorded in manifest.json.
Colab rewrites data.yaml with its actual absolute extraction path.
