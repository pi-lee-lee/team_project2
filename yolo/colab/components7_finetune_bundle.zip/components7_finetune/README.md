# 현재 모델에서 저화질 적응 추가 학습

## 사용할 파일은 2개

- `finetune_components7_lowres.ipynb`: 새 Colab 노트북
- `components7_finetune_bundle.zip`: 기존 모델 + 기존 데이터 + 증강 정책

기존 `train_components7_yolo11.ipynb`가 아니라 위의 **finetune** 노트북을 사용하세요.
이전에 다운로드한 Colab 7클래스 모델을 시작 가중치로 넣었습니다.
원본 가중치 SHA256은 ZIP의 bundle_info.json에 기록하고 노트북 업로드 후 검사합니다.

## 실행 순서

1. https://colab.research.google.com/ 에서 파일 → 노트북 업로드.
2. `finetune_components7_lowres.ipynb`를 엽니다.
3. 런타임 → 런타임 유형 변경 → GPU 선택.
4. 첫 설정 셀부터 위에서 아래로 실행합니다.
5. ZIP 업로드 셀에서 **components7_finetune_bundle.zip** 하나를 선택합니다.
   ZIP에 모델도 있으므로 PT 파일을 따로 업로드하지 않습니다.
6. 데이터 검사 → 효과 미리보기 → 기존 모델 평가 → 추가 학습 → 전후 평가 → 다운로드.
7. 새 PT 파일과 결과 ZIP을 모두 받습니다.

Drive 인증 실패가 있었으므로 `SAVE_TO_DRIVE=False`가 기본입니다.
학습 후 반드시 결과를 내려받으세요. 런타임 삭제 시 /content 결과는 없어질 수 있습니다.

## 선택한 효과

각 학습 이미지에 품질 저하는 최대 한 종류만 적용합니다.

| 효과 | 전체 이미지 기준 확률 | 강도 |
|---|---:|---|
| 저해상도 모사 | 25% | 45~75% 축소 후 원래 크기로 복원 |
| 약한 Gaussian blur | 5% | 3×3, sigma 0.3~0.8 |
| 약한 Motion blur | 5% | 3픽셀 |
| JPEG 압축 | 10% | quality 75~95 |
| 약한 Gaussian noise | 5% | std 0.005~0.015 |
| 위 품질 저하 없음 | 50% | 원래 세부 정보 유지 |

밝기/대비 ±10%는 별도로 20% 확률로 적용합니다.
YOLO의 약한 채도/밝기 변화, 좌우 반전 50%, 상하 반전 20%, 회전 ±20도,
위치 이동 8%, 크기 변화 20%도 적용합니다. Mosaic은 10%로 줄였습니다.

색상별 LED를 구분해야 하므로 **흑백/색조 변경/채널 전환/MixUp은 껐습니다.**
사용자 정의 Albumentations 정책이 기본 ToGray(흑백) 증강도 대체합니다.
증강은 학습 중 자동 적용하므로 변형 JPG를 대량 생성하지 않습니다.
증강 때문에 이미지 크기/박스가 어긋나지 않도록 품질 효과는 좌표를 바꾸지 않습니다.
회전/반전/크기 변환에 대한 박스 갱신은 YOLO가 함께 처리합니다.

## 추가 학습 설정

- 시작: 현재 `best_components7.pt` (Colab에서 학습한 YOLO11n)
- 클래스/사진/분할: 동일한 7클래스, train 243 / val 63
- 추가 USB/빨강 LED 데이터는 아직 포함하지 않았습니다.
- 추가 최대 40 epochs, 조기 종료 patience 12
- 학습률 0.0001 (이전 0.001보다 낮음), AdamW
- GPU, imgsz 640, batch 16
- `resume=False`: 기존 가중치는 불러오되 새 증강/학습률/optimizer로 시작

resume=True는 기존 학습 설정을 복구하므로 이번 목적에 맞지 않습니다.
Colab GPU 전체 학습은 이 파일 준비 과정에서 실행하지 않았습니다.
로컬에서는 정책 동작, 기존 가중치에서의 소규모 1 epoch 학습,
검증 및 새 체크포인트 저장/재로딩을 확인했습니다.

## 개선 여부 확인

학습 전/후를 동일한 두 조건에서 비교합니다.

1. clean_640: 원래 검증 이미지, YOLO 입력 640
2. lowres_320: 검증 이미지만 가로 320으로 축소하고 JPEG90으로 저장, 입력 320

저화질 검증 사본도 학습에는 절대 넣지 않습니다.
동일 이미지의 축소본이므로 독립적으로 새로 촬영한 테스트는 아닙니다.
`comparison_percent.csv` 및 클래스별 표를 보고 저화질 성능 개선과 원본 성능 하락을 함께 확인하세요.
USB를 LED로 착각하는 문제는 실제 오검출 장면을 추가해야 해결될 수 있습니다.

## 결과 모델 적용

`best_components7_finetuned.pt`는 새 후보입니다. 기존 모델을 자동으로 덮어쓰지 않습니다.
다운로드 후 `~/turtlebot3_ws/yolo_training/`에 넣고 노트북에서:

```bash
source /opt/ros/humble/setup.bash
export ROS_DOMAIN_ID=44
cd ~/turtlebot3_ws/yolo_training
.venv/bin/python infer_ros.py --ros-args \
  -p weights:=/home/kim/turtlebot3_ws/yolo_training/best_components7_finetuned.pt \
  -p input_topic:=/csi/image_raw \
  -p imgsz:=320
```

결과 영상: `/yolo/image_raw`. 기존 검출기는 먼저 종료합니다.
기존 `run.sh`의 가중치를 자동 변경하지 않았으므로 위 명령으로 새 후보를 확인하세요.
성능이 나빠지면 weights를 `best_components7.pt`로 되돌리면 됩니다.

공식 증강 API: https://docs.ultralytics.com/integrations/albumentations/
Downscale: https://albumentations.ai/explore/transform/Downscale/docs/
